# Read first

# UNRULY continuation — PAINT1 complete

Graph revisionunruly-kgp-20261011T133431Z; recorded2026-10-11T13:34:31Z /2026-10-11T19:04:31+05:30 (Asia/Kolkata). Repository edition, canonical path knowledge-graph/current on knowledge/unruly-kgp; use .knowledge/CURRENT_GRAPH.json and package/hash verification. Legacy root knowledge-graph records are historical; original/raw evidence is unchanged there and excluded from this package.

One cumulative app: https://lionellmisquitta.github.io/unruly/. Verified appsource0ab2ab79f3c5e187e5e7f951a97c7c86814e6379; CI38140820796 SUCCESS:189 models/193 structured browser scenarios,86 source/test/config hashes. Pages38141558508 SUCCESS;32 hosted bytes verified. Previewpin6f429652ec3d15a6a987aa6e1dc16e8320f6e348. Native maincb1d52089c5cdd159050dc375b92750eb84d8271 unchanged; platform protection not verified. Application/docs basea90bafcc99713a79b8408cd5042ee38080dacdab; later documentation-only graph sync is not a newly tested app build.

Since prior UX2 graph refresh, six checkpoints: PERF1 populated baseline (tests/docs, no deployment), PERF2 renderer boundary, PERF3A sparse persistence, PERF3B decoded cache/compact undo, PERF4 retained compositing, combined PAINT1 round/soft raster painting and growing native smudge. Exact source/CI/artifact/Pages identities in evidence/batch and checkpoints.json.

Next folders/grouping, then masks, clipping/alpha lock, text/fonts, image/reference/clothing patterns, magic wand, magnetic selection and editable pen/path, bucket, gap-aware fill, lasso/enclosure fill, HSL/levels, curves/blur. These are roadmap groups, not a fixed remaining build count. Detailed selection/curve UX not locked. Later textured image tips/grain/splatter/sprinkle, brush-import feasibility, wet-media simulation, whole-canvas rotation (deferred), DPI/exchange, timelapse/neon path, sync/recovery and native optional.

Performance first. Small occupied regions persist sparsely; current working paint buffer is a64-pixel-aligned growing rectangle, not unlimited/tiled disk-resident painting. Maintain32-layer,1024/1MP/4MiB working,8MiB board,100/16MiB history,8MiB decoded-cache and80MiB backing limits. Working/readback/heap/GPU data are separate budgets; total RAM and50-layer/device readiness unverified. Whole live patch still encodes per displayed preview; cold cache priming/full-viewport blending/command CPU remain costs. No dedicatedGPU/OPFS/Rust rewrite. Browser GPU availability does not prove this workload is GPU-accelerated. Native smudge grows without readback; mixed/vector/affine smudge still converts an active bounded snapshot and Undo restores prior artwork. Pixel paint preserves prior vectors/affine raster; round/soft tips do not reproduce all texture recipes.


Read HANDOVER.md for the bounded continuation. Canonical JSONL is in graph/ and knowledge/. Evidence locators/hashes and executed checkpoint summaries are in evidence/batch/. Interactive viewers: exports/graph-explorer.html and exports/OnAir - unruly.html. Confirmed runtime facts, decisions, hypotheses and unknowns are separate.
